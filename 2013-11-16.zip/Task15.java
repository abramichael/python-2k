// int
import java.util.Scanner;
public class Task15{
    public static void main(String[]args){
	    Scanner sc = new Scanner(System.in);
		int N = Integer.parseInt(args[0]);
		int k = 1;
		int M = 0;
		while(N > 0){
		    if(N % 2 == 1){
			    k = k * 10;
			    M = M + k * (N % 10);
			};
			N = N / 10;
		};
		System.out.println(M/10);
	}
}