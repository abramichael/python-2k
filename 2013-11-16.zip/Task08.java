// int 
public class Task08{
	public static void main (String[] args){
		int i;
		int p=1;
		int n=Integer.parseInt(args[0]);
		if (n % 2!=0) {
			for (i=1;i<=n;i=i+2) {
				p=p*i;
			}
		}	
		else {
			for (i=2;i<=n;i=i+2) {
				p=p*i;
			}
		}
		System.out.println ("n!!= " + p);
	}
}