// double
import java.util.Scanner;
import java.lang.Math;
public class Task11{
    public static void main(String[]argc){
	    Scanner sc = new Scanner(System.in);
		double s = 0;
		double x = Double.parseDouble(args[0]);
		int n = Integer.parseInt(args[1]);
		s = Math.cos(x);
		while (n > 1){
			n--;
			s = Math.cos(x + s);
		};
		System.out.println(s);
	}
}