// double
public class Task05{
	public static void main (String[] args){
		double x=Double.parseDouble(args[0]);
		double y;
		y=(x>2) ? (x*x-1)/(x+2):(x<=2 && x>0) ?  (x*x-1)*(x+2):x*x*(1+2*x);
		System.out.println("y=" + y);
	}
}		

		