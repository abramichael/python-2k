// int
public class Task07{
	public static void main (String[] args){
		int i=2;
		int k=Integer.parseInt(args[0]);
		System.out.println ("Enter digit: "+ k);
		for (i=2;i<=9;i++) {
			System.out.println(k + "x" + i +"=" +k*i);
		}
	}
}