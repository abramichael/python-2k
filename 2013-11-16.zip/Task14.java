// int

import java.util.Scanner;
public class Task14{
    public static void main(String[]args){
	    Scanner sc = new Scanner(System.in);
		int N = Integer.parseInt(args[0]);
		int k = 0;
		while(N > 0){
		    N = N / 10;
			k++;
		};
		System.out.println(k);
	}
}