// int
import java.util.Scanner;
public class Task10{
    public static void main(String[]args){
	    Scanner sc = new Scanner(System.in);
	    int n = Integer.parseInt(args[0]);
	    double s = 1;
	    for (int i = 1;i <= n;i++){
			s = s * (2 * i) / (2 * i - 1) * (2 * i) / (2 * i + 1);	        
	    };
		System.out.println(s);
	}
}
