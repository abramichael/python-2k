// double

import java.util.Scanner;
public class Task16{
    public static void main(String[] args){
	    final double e = 0.000000001;
	    Scanner sc = new Scanner(System.in);
		double x = Double.parseDouble(args[0]);
		int k = 1;
		int i = 0;
		double z = 1;
		double s = x;
		while(z > e){
		    i++;
			k = -1 * k;
			z = z * (x * x) / (i * i);
			s = s + z * k;
		   
		};
		System.out.println(s);
	}
}