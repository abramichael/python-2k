// int
public class Task04{
	public static void main(String[] args) {
		int x=Integer.parseInt(args[0]),y;
			if (x>2)
				y=x*x-1/x+2;
			else
				if (0<x && x<=2)
					y=(x*x-1)*(x+2);
				else 
					y=x*x*(1+2*x);
	   		System.out.println (y) ;
			
	}	
}
