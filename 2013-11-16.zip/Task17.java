// double

import java.util.Scanner;
public class Task17{
    public static void main(String[] args){
	    final double e = 0.000000001;
	    Scanner sc = new Scanner(System.in);
		double x = Double.parseDouble(args[0]);
		int k = 1;
		int i = 0;
		double z = 1;
		double s = 1;
		while(z > e){
		    i++;
			k = -1 * k;
			z = z * (x * x) / (i * (i + 1));
			s = s + z * k;
		   System.out.println(s);
		};
		
	}
}