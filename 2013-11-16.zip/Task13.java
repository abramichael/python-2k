// int

import java.util.Scanner;
public class Task13{
    public static void main(String[]args){
	    Scanner sc = new Scanner(System.in);
		int N = Integer.parseInt(args[0]);
		int s = 0;
		while (N > 0){
		    s = s + N % 10 - N % 100 / 10;
			N = N / 100;
		};
		System.out.println(s);
	}
}