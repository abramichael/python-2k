// array int
public class Task12{
    public static void main(String[]args){
	    int n = args.length;
		int a = 0;
		int s = 0;
		for (int i = 1;i <= n;i++){
		    a = Integer.parseInt(args[i - 1]);
			s = s * 10 + a;
		};
		System.out.println(s);
	}
}